I put together this demo as a first test of getting the Game Boy running.

It loads some tiles and a map, and then scrolls the background left.

It was tested using the TASM assembler and the NO$GMB emulator.

The "setpath.bat" batch file sets my compile paths to tasm.exe and rgbfix.exe.  The
"mk.bat" batch file runs my compile.


